<?php
/**
 * Raw Llama\Request Endpoint Tests
 * 
 * Tests server-coro endpoints using direct Llama\Request calls
 * (not through Odin client). These endpoints may need additional
 * server-coro implementation work.
 * 
 * Usage:
 *   php test_raw_endpoints.php -m /path/to/model.gguf [--ctx-size 4096] [--parallel 4]
 */

declare(strict_types=1);

// Test tracking
$results = [];
$totalTests = 0;
$passedTests = 0;

function test(string $name, callable $fn): void
{
    global $results, $totalTests, $passedTests;
    $totalTests++;
    
    echo "\n" . str_repeat('=', 60) . "\n";
    echo "TEST: $name\n";
    echo str_repeat('-', 60) . "\n";
    
    $start = microtime(true);
    try {
        $fn();
        $elapsed = microtime(true) - $start;
        echo "\n✅ PASSED - " . number_format($elapsed, 2) . "s\n";
        $results[$name] = ['status' => 'PASSED', 'time' => $elapsed];
        $passedTests++;
    } catch (Throwable $e) {
        $elapsed = microtime(true) - $start;
        echo "\n❌ FAILED: " . $e->getMessage() . "\n";
        echo "   at " . basename($e->getFile()) . ":" . $e->getLine() . "\n";
        $results[$name] = ['status' => 'FAILED', 'error' => $e->getMessage(), 'time' => $elapsed];
    }
}

function llama_request(string $method, string $path, array $body = []): array
{
    $params = [
        'method' => $method,
        'path' => $path,
        'body' => $body ? json_encode($body) : '',
        'headers' => ['Content-Type' => ['application/json'], 'X-Response-Type' => ['raw']],
    ];
    
    $req = new \Llama\Request($params);
    
    if ($req->isStream()) {
        throw new RuntimeException("Unexpected streaming response for $path");
    }
    
    $data = $req->getData();
    if ($data === null || $data === '') {
        return [];
    }
    
    $decoded = json_decode($data, true);
    if (json_last_error() !== JSON_ERROR_NONE) {
        throw new RuntimeException("Invalid JSON response: " . json_last_error_msg() . " - data: " . substr($data, 0, 100));
    }
    
    return $decoded;
}

function assert_true(bool $condition, string $message = ''): void
{
    if (!$condition) {
        throw new RuntimeException("Assertion failed: $message");
    }
}

function assert_key_exists(array $arr, string $key, string $message = ''): void
{
    if (!array_key_exists($key, $arr)) {
        throw new RuntimeException("Key '$key' not found: $message. Keys: " . implode(', ', array_keys($arr)));
    }
}

\Co\run(function () {
    global $argv, $results, $totalTests, $passedTests;
    
    echo "╔══════════════════════════════════════════════════════════╗\n";
    echo "║        Raw Llama\\Request Endpoint Tests                  ║\n";
    echo "╚══════════════════════════════════════════════════════════╝\n\n";
    
    if (!swoole_llama_init($argv)) {
        echo "ERROR: Failed to initialize llama\n";
        return;
    }
    
    echo "Loading model...\n";
    while (swoole_llama_ready() === 0) {
        \Co::sleep(0.1);
    }
    
    if (swoole_llama_ready() === -1) {
        echo "ERROR: Model failed to load\n";
        return;
    }
    echo "Model loaded\n";
    
    // =========================================================================
    // TEST 1: GET /health
    // =========================================================================
    test('GET /health', function() {
        $response = llama_request('GET', '/health');
        
        assert_key_exists($response, 'status', 'Health response');
        echo "Status: {$response['status']}\n";
        
        assert_true($response['status'] === 'ok', 'Status should be ok');
    });
    
    // =========================================================================
    // TEST 2: GET /v1/models
    // =========================================================================
    test('GET /v1/models', function() {
        $response = llama_request('GET', '/v1/models');
        
        assert_key_exists($response, 'data', 'Models response');
        assert_true(is_array($response['data']), 'data should be array');
        
        echo "Models found: " . count($response['data']) . "\n";
        foreach ($response['data'] as $model) {
            echo "  - {$model['id']}\n";
        }
    });
    
    // =========================================================================
    // TEST 3: POST /tokenize
    // =========================================================================
    test('POST /tokenize', function() {
        $response = llama_request('POST', '/tokenize', [
            'content' => 'Hello, world!',
        ]);
        
        assert_key_exists($response, 'tokens', 'Tokenize response');
        assert_true(is_array($response['tokens']), 'tokens should be array');
        
        $tokens = $response['tokens'];
        echo "Token count: " . count($tokens) . "\n";
        echo "Tokens: " . implode(', ', array_slice($tokens, 0, 10)) . (count($tokens) > 10 ? '...' : '') . "\n";
    });
    
    // =========================================================================
    // TEST 4: POST /detokenize
    // =========================================================================
    test('POST /detokenize', function() {
        // First tokenize
        $tokenized = llama_request('POST', '/tokenize', [
            'content' => 'Hello, world!',
        ]);
        
        $tokens = $tokenized['tokens'];
        echo "Input tokens: " . implode(', ', $tokens) . "\n";
        
        // Then detokenize
        $response = llama_request('POST', '/detokenize', [
            'tokens' => $tokens,
        ]);
        
        assert_key_exists($response, 'content', 'Detokenize response');
        echo "Detokenized: {$response['content']}\n";
        
        // Should match original (approximately - some tokenizers may differ slightly)
        assert_true(
            strpos($response['content'], 'Hello') !== false,
            'Detokenized should contain Hello'
        );
    });
    
    // =========================================================================
    // TEST 5: POST /apply-template
    // =========================================================================
    test('POST /apply-template', function() {
        $response = llama_request('POST', '/apply-template', [
            'messages' => [
                ['role' => 'system', 'content' => 'You are helpful.'],
                ['role' => 'user', 'content' => 'Hello!'],
            ],
        ]);
        
        assert_key_exists($response, 'prompt', 'Apply-template response');
        
        $prompt = $response['prompt'];
        echo "Formatted prompt length: " . strlen($prompt) . " chars\n";
        echo "Preview: " . substr($prompt, 0, 100) . "...\n";
        
        // Should contain the messages
        assert_true(strpos($prompt, 'Hello') !== false, 'Prompt should contain message');
    });
    
    // =========================================================================
    // TEST 6: GET /props
    // =========================================================================
    test('GET /props', function() {
        $response = llama_request('GET', '/props');
        
        assert_key_exists($response, 'total_slots', 'Props response');
        
        echo "Total slots: {$response['total_slots']}\n";
        if (isset($response['default_generation_settings'])) {
            $settings = $response['default_generation_settings'];
            echo "Default n_ctx: " . ($settings['n_ctx'] ?? 'N/A') . "\n";
        }
    });
    
    // =========================================================================
    // TEST 7: POST /v1/embeddings (if supported)
    // =========================================================================
    test('POST /v1/embeddings', function() {
        $response = llama_request('POST', '/v1/embeddings', [
            'input' => 'Hello, world!',
            'model' => 'local-model',
        ]);
        
        // Chat models return error for embeddings - this is expected
        if (isset($response['error'])) {
            echo "Model does not support embeddings (expected for chat models)\n";
            echo "Error: " . ($response['error']['message'] ?? json_encode($response['error'])) . "\n";
            // Skip test - not a failure for chat models
            return;
        }
        
        assert_key_exists($response, 'data', 'Embeddings response');
        
        $embedding = $response['data'][0]['embedding'] ?? [];
        echo "Embedding dimensions: " . count($embedding) . "\n";
        
        if (count($embedding) > 0) {
            echo "First 3 values: " . implode(', ', array_map(fn($v) => number_format($v, 4), array_slice($embedding, 0, 3))) . "...\n";
        }
    });
    
    // =========================================================================
    // TEST 8: GET /slots (if endpoint enabled)
    // =========================================================================
    test('GET /slots', function() {
        try {
            $response = llama_request('GET', '/slots');
            
            assert_true(is_array($response), 'Slots should be array');
            
            echo "Slots: " . count($response) . "\n";
            foreach ($response as $slot) {
                $state = $slot['state'] ?? 'unknown';
                $id = $slot['id'] ?? '?';
                echo "  Slot $id: $state\n";
            }
        } catch (Throwable $e) {
            if (strpos($e->getMessage(), 'disabled') !== false ||
                strpos($e->getMessage(), 'not found') !== false ||
                strpos($e->getMessage(), '404') !== false) {
                echo "Slots endpoint not enabled (use --slot-endpoints flag)\n";
                throw $e;
            }
            throw $e;
        }
    });
    
    // =========================================================================
    // TEST 9: POST /v1/chat/completions (raw, non-streaming)
    // =========================================================================
    test('POST /v1/chat/completions (raw)', function() {
        $response = llama_request('POST', '/v1/chat/completions', [
            'model' => 'local-model',
            'messages' => [
                ['role' => 'user', 'content' => 'Say "test" and nothing else.'],
            ],
            'max_tokens' => 50,
            'temperature' => 0.0,
            'stream' => false,
        ]);
        
        assert_key_exists($response, 'choices', 'Chat response');
        
        $choice = $response['choices'][0] ?? [];
        $message = $choice['message'] ?? [];
        $content = $message['content'] ?? '';
        $reasoning = $message['reasoning_content'] ?? '';
        
        echo "Content: " . ($content ?: '(empty)') . "\n";
        if ($reasoning) {
            echo "Reasoning: " . substr($reasoning, 0, 100) . (strlen($reasoning) > 100 ? '...' : '') . "\n";
        }
        
        // Either content or reasoning_content should exist (thinking models use reasoning_content)
        $hasOutput = strlen($content) > 0 || strlen($reasoning) > 0;
        assert_true($hasOutput, 'Should have content or reasoning_content');
    });
    
    // =========================================================================
    // TEST 10: POST /v1/completions (raw)
    // =========================================================================
    test('POST /v1/completions (raw)', function() {
        $response = llama_request('POST', '/v1/completions', [
            'model' => 'local-model',
            'prompt' => 'The meaning of life is',
            'max_tokens' => 30,
            'temperature' => 0.5,
        ]);
        
        assert_key_exists($response, 'choices', 'Completions response');
        
        $text = $response['choices'][0]['text'] ?? '';
        echo "Completion: The meaning of life is$text\n";
        
        assert_true(strlen($text) > 0, 'Should have completion text');
    });
    
    // =========================================================================
    // SUMMARY
    // =========================================================================
    echo "\n" . str_repeat('=', 60) . "\n";
    echo "SUMMARY\n";
    echo str_repeat('=', 60) . "\n\n";
    
    foreach ($results as $name => $result) {
        $status = $result['status'] === 'PASSED' ? '✅' : '❌';
        $time = number_format($result['time'], 2);
        echo "$status $name ({$time}s)";
        if ($result['status'] === 'FAILED') {
            echo " - " . substr($result['error'] ?? '', 0, 40);
        }
        echo "\n";
    }
    
    echo "\n" . str_repeat('-', 60) . "\n";
    echo "Total: $passedTests/$totalTests tests passed\n";
    
    if ($passedTests === $totalTests) {
        echo "\n🎉 All tests passed!\n";
    } else {
        echo "\n⚠️  Some tests failed (may need server flags or specific model).\n";
    }
    
    swoole_llama_shutdown();
});
