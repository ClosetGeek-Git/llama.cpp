// Empty state
export const EMPTY_MD = '';
