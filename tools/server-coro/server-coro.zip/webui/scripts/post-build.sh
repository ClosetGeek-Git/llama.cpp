rm -rf ../public/_app;
rm ../public/favicon.svg;
rm ../public/index.html;
