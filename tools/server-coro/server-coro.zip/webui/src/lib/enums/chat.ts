export enum ChatMessageStatsView {
	GENERATION = 'generation',
	READING = 'reading'
}
