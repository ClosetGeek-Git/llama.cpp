export enum ModelModality {
	TEXT = 'TEXT',
	AUDIO = 'AUDIO',
	VISION = 'VISION'
}
