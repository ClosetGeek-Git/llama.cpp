export const VIEWPORT_GUTTER = 8;
export const MENU_OFFSET = 6;
