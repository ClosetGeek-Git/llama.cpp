export const MAX_BUNDLE_SIZE = 2 * 1024 * 1024;
