export const INPUT_CLASSES = `
    bg-muted/70 dark:bg-muted/85
    border border-border/30 focus-within:border-border  dark:border-border/20 dark:focus-within:border-border
    outline-none
    text-foreground
`;
