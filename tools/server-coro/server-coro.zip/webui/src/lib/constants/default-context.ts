export const DEFAULT_CONTEXT = 4096;
