<?php
/**
 * Test to verify that Qwen3 Does not create reasoning stream\
 * - note: this was verified as of 1-23-2026
 */

use python\json;

if (!extension_loaded('swoole_llama')) {
    die("Error: swoole_llama extension not loaded\n");
}

\Co\run(function () {
    echo "=== Large Context Test ===\n\n";
    
    // Test 1: Load qwen model
    echo "1. Loading model 'Qwen3-4B-Thinking-2507-Q4_K_M'...\n";
    if (!swoole_llama_load_model(['test', '-m', '/home/jason-dev/swoole/Qwen3-4B-Thinking-2507-Q4_K_M.gguf', '--ctx-size', '16048', '--parallel', '2', '--reasoning-budget', '0', '--chat-template-file', '/home/jason-dev/swoole/llama.cpp/models/templates/Qwen-Qwen3-0.6B.jinja', '--log-disable'])) {
        echo "   FAILED: swoole_llama_load_model() returned false\n";
        return;
    }
    echo "   OK: Qwen3-4B-Thinking-2507-Q4_K_M loading started\n";
    
    // Test 2: Wait for qwen to be ready
    echo "2. Waiting for 'Qwen3-4B-Thinking-2507-Q4_K_M' to be ready...\n";
    while (swoole_llama_model_ready('Qwen3-4B-Thinking-2507-Q4_K_M') === 0) {
        \Co::sleep(0.1);
    }
    if (swoole_llama_model_ready('Qwen3-4B-Thinking-2507-Q4_K_M') === -1) {
        echo "   FAILED: Qwen3-4B-Thinking-2507-Q4_K_M failed to load\n";
        return;
    }
    echo "   OK: Qwen3-4B-Thinking-2507-Q4_K_M ready\n";
    
    // Test 3: List models
    echo "3. Listing models...\n";
    $models = swoole_llama_list_models();
    echo "   OK: " . json_encode($models) . "\n";
    
    
    // Test 4: Make request to Qwen3-4B-Thinking-2507-Q4_K_M
    echo "4. Making request with model='Qwen3-4B-Thinking-2507-Q4_K_M'...\n";
    try {
        $req = new \Llama\Request([
            
            'method' => 'POST',
            'path' => '/v1/chat/completions',
            'body' => json_encode([
                'model' => 'Qwen3-4B-Thinking-2507-Q4_K_M',
                'messages' => [['role' => 'user', 'content' => 'Say hello in spanish']],
                'max_tokens' => 16,
                'temperature' => 0.0,
                'stream' => false,
            ]),
            'headers' => ['Content-Type' => ['application/json']],
            /*
            'method' => 'POST',
            'path' => '/test/stream',
            'body' => json_encode([
                'model' => 'Qwen3-4B-Thinking-2507-Q4_K_M',
                'n_chunks' => 5,
                'stream' => true
            ]),
            'headers' => ['content-type' => ['application/json']],            
            */
        ]);

        if($req->isStream())
        {
            $chunks = 0;
            $content = '';
            $reasoning = '';
            $firstData = $req->getData();
            if ($firstData !== null) {
                $chunks++;
                $data = $firstData;
                if (isset($data['choices'][0]['delta']['reasoning_content'])) {
                    $reasoning .= $data['choices'][0]['delta']['reasoning_content'];
                }
                if (isset($data['choices'][0]['delta']['content'])) {
                    $content .= $data['choices'][0]['delta']['content'];
                }
            }
            while (($chunk = $req->next()) !== null) {
                $chunks++;
                if (isset($chunk['choices'][0]['delta']['reasoning_content'])) {
                    $reasoning .= $chunk['choices'][0]['delta']['reasoning_content'];
                }
                if (isset($chunk['choices'][0]['delta']['content'])) {
                    $content .= $chunk['choices'][0]['delta']['content'];
                }
            }
            echo "Reasoning: " . ($reasoning ?: '(empty)') . "\n";
            echo "Content: " . ($content ?: '(empty)') . "\n";

        } else {
            $data = $req->getData();
            
            $choice = $data['choices'][0] ?? [];
            $message = $choice['message'] ?? [];
            $content = $message['content'] ?? '';
            $reasoning = $message['reasoning_content'] ?? '';

            echo "Reasoning: " . ($reasoning ?: '(empty)') . "\n";
            echo "Content: " . ($content ?: '(empty)') . "\n";
        }
    } catch (Exception $e) {
        echo "   FAILED: " . $e->getMessage() . "\n";
    }
    
    
    // Test 5: Unload qwen
    echo "5. Unloading 'Qwen3-4B-Thinking-2507-Q4_K_M'...\n";
    if (!swoole_llama_unload_model('Qwen3-4B-Thinking-2507-Q4_K_M')) {
        echo "   FAILED: swoole_llama_unload_model() returned false\n";
    } else {
        echo "   OK: Model unloaded\n";
    }
    
    // Test 6: Verify model list is empty
    echo "6. Verifying model list is empty...\n";
    $models = swoole_llama_list_models();
    if (empty($models)) {
        echo "   OK: Model list is empty\n";
    } else {
        echo "   FAILED: Model list not empty: " . json_encode($models) . "\n";
    }
    
    echo "\n=== All tests completed ===\n";
});
